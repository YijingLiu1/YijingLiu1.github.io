var searchData=
[
  ['dirx_12',['dirX',['../class_ball.html#a868a2076c663adea8f7602661a81877f',1,'Ball']]],
  ['draw_13',['Draw',['../class_menu.html#a85e25c9dc9cbd47fb6f4cdfc72d4e59e',1,'Menu::Draw()'],['../class_text.html#af4bb084ff0f66ad827ef6b006f9b0ebd',1,'Text::Draw()']]]
];
