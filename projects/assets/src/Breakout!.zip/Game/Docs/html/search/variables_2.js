var searchData=
[
  ['dirx_146',['dirX',['../class_ball.html#a868a2076c663adea8f7602661a81877f',1,'Ball']]]
];
