var searchData=
[
  ['velocity_153',['velocity',['../class_paddle.html#ad3d67ab58ead484bea9bab5ac6904cb4',1,'Paddle']]]
];
