var searchData=
[
  ['ball_0',['Ball',['../class_ball.html',1,'Ball'],['../class_ball.html#ab9ce613e29fbda8012d95ecc20bf9fe3',1,'Ball::Ball()']]],
  ['brick_1',['Brick',['../class_brick.html',1,'']]],
  ['brickoffsetx_2',['brickOffsetX',['../class_level.html#a2d31713f3a86dea07857f476fcaa3316',1,'Level']]],
  ['bricks_3',['bricks',['../class_level.html#ab9df2ed29ec35724e53e3595c0a76c98',1,'Level']]]
];
