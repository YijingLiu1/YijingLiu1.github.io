var searchData=
[
  ['brickoffsetx_143',['brickOffsetX',['../class_level.html#a2d31713f3a86dea07857f476fcaa3316',1,'Level']]],
  ['bricks_144',['bricks',['../class_level.html#ab9df2ed29ec35724e53e3595c0a76c98',1,'Level']]]
];
