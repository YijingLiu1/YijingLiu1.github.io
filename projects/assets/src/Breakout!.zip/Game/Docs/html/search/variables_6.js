var searchData=
[
  ['texture_152',['texture',['../class_text.html#aea2a82ef1d8b4d448b6b3e524bce2cc2',1,'Text']]]
];
