var searchData=
[
  ['rect_148',['rect',['../class_text.html#abfd7707d427d99386fa552cd4a114487',1,'Text']]],
  ['renderer_149',['renderer',['../class_entity.html#a2747dfdd9fa4fe743c8b80450bc99dbd',1,'Entity::renderer()'],['../class_text.html#ad26c71bb23e87ed69b9e38210bdde932',1,'Text::renderer()']]]
];
