var searchData=
[
  ['draw_94',['Draw',['../class_menu.html#a85e25c9dc9cbd47fb6f4cdfc72d4e59e',1,'Menu::Draw()'],['../class_text.html#af4bb084ff0f66ad827ef6b006f9b0ebd',1,'Text::Draw()']]]
];
