var searchData=
[
  ['rect_36',['rect',['../class_text.html#abfd7707d427d99386fa552cd4a114487',1,'Text']]],
  ['render_37',['Render',['../class_ball.html#a1103f2193c0e478926eb6af95a65d46e',1,'Ball::Render()'],['../class_entity.html#a5badc77fcf1670b4cac1c7f20d3461af',1,'Entity::Render()'],['../class_level.html#a4a2116ee99f3ededcf7b8e89a0ce1fde',1,'Level::Render()'],['../class_paddle.html#a166255dfac354af75059ed4a72e1a0ee',1,'Paddle::Render()']]],
  ['renderer_38',['renderer',['../class_entity.html#a2747dfdd9fa4fe743c8b80450bc99dbd',1,'Entity::renderer()'],['../class_text.html#ad26c71bb23e87ed69b9e38210bdde932',1,'Text::renderer()']]],
  ['resourcemanager_39',['ResourceManager',['../class_resource_manager.html',1,'']]],
  ['run_40',['Run',['../class_game.html#a96341ca5b54d90adc3ecb3bf0bcd2312',1,'Game']]]
];
