var searchData=
[
  ['font_147',['font',['../class_text.html#ae23ac53acb57e760b91c81d8c4aec8c7',1,'Text']]]
];
