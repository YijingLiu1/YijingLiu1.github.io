var searchData=
[
  ['render_116',['Render',['../class_ball.html#a1103f2193c0e478926eb6af95a65d46e',1,'Ball::Render()'],['../class_entity.html#a5badc77fcf1670b4cac1c7f20d3461af',1,'Entity::Render()'],['../class_level.html#a4a2116ee99f3ededcf7b8e89a0ce1fde',1,'Level::Render()'],['../class_paddle.html#a166255dfac354af75059ed4a72e1a0ee',1,'Paddle::Render()']]],
  ['run_117',['Run',['../class_game.html#a96341ca5b54d90adc3ecb3bf0bcd2312',1,'Game']]]
];
