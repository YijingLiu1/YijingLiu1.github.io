//
// Created by Yijing Liu on 2021/2/16.
//

#include "../include/Menu.h"

/**
 * constructor of the Menu class
 *
 * @param font the font for the menu
 * @param langData the vector for game texts in requested language
 */
Menu::Menu(TTF_Font* font, std::vector<std::string> langData)
  : font(font), langData(langData) {
  state = 0;
  choice = 0;

  int y = SCREEN_HEIGHT / 2 - 100;

  for (int i = 0; i < 3; i++) {
    textRect[i].w = 160;
    textRect[i].h = 30;
    textRect[i].x = (SCREEN_WIDTH - textRect[i].w) / 2;
    textRect[i].y = y;
    y += textRect[i].h + 20 * (2 - i);
  }

  selection.w = 10;
  selection.h = 10;
  selection.x = textRect[1].x - 20;
  selection.y = textRect[1].y + textRect[1].h / 2 - selection.h / 2;

  color = {0xFF, 0x60, 0x40, 0x00};

  pauseText[0] = langData[0];
  pauseText[1] = langData[1];
  pauseText[2] = langData[2];

  winText[0] = langData[3];
  winText[1] = langData[4];
  winText[2] = langData[2];

  loseText[0] = langData[5];
  loseText[1] = langData[6];
  loseText[2] = langData[2];

}

/**
 * destructor of the Menu class
 */
Menu::~Menu() {
  for (int i = 0; i < 3; i++) {
    SDL_DestroyTexture(textures[i]);
  }
}

/**
 * Update pause texts in the menu.
 *
 * @param renderer the SDL renderer
 */
void Menu::Pause(SDL_Renderer* renderer) {
  for (int i = 0; i < 3; i++) {
    textures[i] = textureSwitch(pauseText[i], renderer);
  }
}

/**
 * Update win texts in the menu.
 *
 * @param renderer the SDL renderer
 */
void Menu::Win(SDL_Renderer* renderer) {
  for (int i = 0; i < 3; i++) {
    textures[i] = textureSwitch(winText[i], renderer);
  }
}

/**
 * Update lose texts in the menu.
 *
 * @param renderer the SDL renderer
 */
void Menu::Lose(SDL_Renderer* renderer) {
  for (int i = 0; i < 3; i++) {
    textures[i] = textureSwitch(loseText[i], renderer);
  }
}

/**
 * Update selection point position in the menu.
 */
void Menu::Select() {
  if (!choice) {
    selection.x = textRect[2].x - 20;
    selection.y = textRect[2].y + textRect[2].h / 2 - selection.h / 2;
  }
  else {
    selection.x = textRect[1].x - 20;
    selection.y = textRect[1].y + textRect[1].h / 2 - selection.h / 2;
  }
}

/**
 * Switch texture of texts in the menu.
 *
 * @param text the text to render
 * @param renderer the SDL renderer
 * @return texture the SDL texture pointer of texts
 */
SDL_Texture* Menu::textureSwitch(std::string text, SDL_Renderer* renderer) {
  SDL_Surface* surface = TTF_RenderUTF8_Solid(font, text.c_str(), color);
  SDL_Texture* texture = SDL_CreateTextureFromSurface(renderer, surface);
  return texture;
}

/**
 * Render texts and selection in the menu.
 *
 * @param renderer the SDL renderer
 */
void Menu::Draw(SDL_Renderer* renderer) {
  for (int i = 0; i < 3; i++) {
    SDL_RenderCopy(renderer, textures[i], nullptr, &textRect[i]);
  }
  SDL_SetRenderDrawColor(renderer, 0xFF, 0x60, 0x40, 0xFF);
  SDL_RenderFillRect(renderer, &selection);
}
