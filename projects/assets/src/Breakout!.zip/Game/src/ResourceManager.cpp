//
// Created by Yijing Liu on 2021/2/16.
//

#include "../include/ResourceManager.h"

/**
 * constructor of the ResourceManager class
 */
ResourceManager::ResourceManager(){
}

/**
 * destructor of the ResourceManager class
 */
ResourceManager::~ResourceManager(){
}

/**
 * 'equivalent' to constructor
 */
int ResourceManager::startUp() {
}

/**
 * 'equivalent' to destructor
 */
int ResourceManager::shutDown() {
}

/** the cache storing textures */
TextureCache ResourceManager::_textureCache;
/** the cache storing sounds */
SoundCache ResourceManager::_soundCache;
/** the cache storing musics */
MusicCache ResourceManager::_musicCache;
/** the cache storing fonts */
FontCache ResourceManager::_fontCache;
/** the cache storing stages */
StageCache ResourceManager::_stageCache;

/**
 * Get the texture from TextureCache.
 *
 * @param renderer the SDL renderer
 * @param resourcePath the resource path for the texture
 * @return the SDL_Texture file pointer of the texture
 */
SDL_Texture* ResourceManager::getTexture(SDL_Renderer* renderer, const char* resourcePath) {
  return _textureCache.getTexture(renderer, resourcePath);
}

/**
 * Get the sound from SoundCache.
 *
 * @param resourcePath the resource path for the sound
 * @return the Mix_Chunk file pointer of the sound
 */
Mix_Chunk* ResourceManager::getSound(const char* resourcePath) {
  return _soundCache.getSound(resourcePath);
}

/**
 * Get the music from MusicCache.
 *
 * @param resourcePath the resource path for the music
 * @return the Mix_Music file pointer of the music
 */
Mix_Music* ResourceManager::getMusic(const char* resourcePath) {
  return _musicCache.getMusic(resourcePath);
}

/**
 * Get the font from FontCache.
 *
 * @param resourcePath the resource path for the font
 * @param size the font size
 * @return the TTF_Font file pointer of the font and size
 */
TTF_Font* ResourceManager::getFont(const char* resourcePath, int size) {
  return _fontCache.getFont(resourcePath, size);
}

/**
 * Load the stage into StageCache.
 *
 * @param resourcePath the resource path for the stage file
 */
void ResourceManager::loadStage(const char* resourcePath) {
  _stageCache.LoadStage(resourcePath);
}

/**
 * Get the stage from StageCache.
 *
 * @param int the stage number to get
 * @return the vector of the info of stage
 */
std::vector<std::vector<unsigned int>> ResourceManager::getStage(int stage) {
  return _stageCache.GetStage(stage);
}

/** the singleton instance */
ResourceManager* ResourceManager::instance_ = 0;
