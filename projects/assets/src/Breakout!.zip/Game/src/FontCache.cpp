//
// Created by Yijing Liu on 2021/2/17.
//

#include "../include/FontCache.h"

/**
 * constructor of the FontCache class
 */
FontCache::FontCache() {}

/**
 * destructor of the FontCache class
 */
FontCache::~FontCache() {
  clearFont();
}

/**
 * Get the font from cache.
 *
 * @param resourcePath the resource path for the font
 * @param size the font size
 * @return the TTF_Font file pointer of the font and size
 */
TTF_Font* FontCache::getFont(const char* resourcePath, int size) {
  // look up and see if in the map
  auto mit = _resourceMap.find(resourcePath);

  // check if not in the map
  if (mit == _resourceMap.end()) {
    // Load the resource
    TTF_Font* newResource = TTF_OpenFont(resourcePath, size);

    if(newResource==NULL){
      SDL_Log("Failed to allocate font..");
      return newResource;
    }else{
      SDL_Log("Allocating new font..");
    }

    // Insert it into the map
    _resourceMap.insert(std::make_pair(resourcePath, newResource));

    return newResource;
  }

  SDL_Log("Loading from already allocated fonts..");
  return mit->second;
}

/**
 * Clear the font cache.
 */
void FontCache::clearFont() {
  while (_resourceMap.begin() != _resourceMap.end())
  {
    _resourceMap.erase(_resourceMap.begin());
  }
  SDL_Log("Clearing allocated fonts..");
}

