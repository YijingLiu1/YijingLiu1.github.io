//
// Created by Yijing Liu on 2021/2/16.
//

#include "../include/Text.h"

/**
 * constructor of the Text class
 *
 * @param x the x position of the text
 * @param y the y position of the text
 * @param renderer the SDL renderer
 * @param font the font for the menu
 */
Text::Text(int x, int y, SDL_Renderer* renderer, TTF_Font* font)
        : renderer(renderer), font(font) {
  surface = TTF_RenderText_Solid(font, "0", {0xFF, 0x60, 0x40, 0x00});
  texture = SDL_CreateTextureFromSurface(renderer, surface);

  int width, height;
  SDL_QueryTexture(texture, nullptr, nullptr, &width, &height);

  rect.x = x;
  rect.y = y;
  rect.w = width;
  rect.h = height;
}

/**
 * destructor of the Text class
 */
Text::~Text() {
  SDL_FreeSurface(surface);
  SDL_DestroyTexture(texture);
}

/**
 * Render texts in the game stage.
 */
void Text::Draw()
{
  SDL_RenderCopy(renderer, texture, nullptr, &rect);
}

/**
 * Set score info in the text.
 */
void Text::SetScore(int score, std::vector<std::string> langData)
{
  SDL_FreeSurface(surface);
  SDL_DestroyTexture(texture);

  std::string scoreText = langData[8] + std::to_string(score);
  surface = TTF_RenderUTF8_Solid(font, scoreText.c_str(), {0xFF, 0x60, 0x40, 0x00});
  texture = SDL_CreateTextureFromSurface(renderer, surface);

  int width, height;
  SDL_QueryTexture(texture, nullptr, nullptr, &width, &height);
  rect.w = width;
  rect.h = height;
}

/**
 * Set lives info in the text.
 */
void Text::SetLives(int lives, std::vector<std::string> langData)
{
  SDL_FreeSurface(surface);
  SDL_DestroyTexture(texture);

  std::string livesText = langData[7] + std::to_string(lives);
  surface = TTF_RenderUTF8_Solid(font, livesText.c_str(), {0xFF, 0x60, 0x40, 0x00});
  texture = SDL_CreateTextureFromSurface(renderer, surface);

  int width, height;
  SDL_QueryTexture(texture, nullptr, nullptr, &width, &height);
  rect.w = width;
  rect.h = height;
}