//
// Created by Yijing Liu on 2021/2/17.
//

#include "../include/MusicCache.h"

/**
 * constructor of the MusicCache class
 */
MusicCache::MusicCache() {}

/**
 * destructor of the MusicCache class
 */
MusicCache::~MusicCache() {
  clearMusic();
}

/**
 * Get the music from cache.
 *
 * @param resourcePath the resource path for the music
 * @return the Mix_Music file pointer of the music
 */
Mix_Music* MusicCache::getMusic(const char* resourcePath) {
  // look up and see if in the map
  auto mit = _resourceMap.find(resourcePath);

  // check if not in the map
  if (mit == _resourceMap.end()) {
    // Load the resource
    Mix_Music* newResource = Mix_LoadMUS(resourcePath);

    if(newResource==NULL){
      SDL_Log("Failed to allocate music..");
      return newResource;
    }else{
      SDL_Log("Allocating new music..");
    }

    // Insert it into the map
    _resourceMap.insert(std::make_pair(resourcePath, newResource));

    return newResource;
  }

  SDL_Log("Loading from already allocated musics..");
  return mit->second;
}

/**
 * Clear the music cache.
 */
void MusicCache::clearMusic() {
  while (_resourceMap.begin() != _resourceMap.end())
  {
    _resourceMap.erase(_resourceMap.begin());
  }
  SDL_Log("Clearing allocated musics..");
}
