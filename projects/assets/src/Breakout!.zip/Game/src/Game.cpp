//
// Created by Yijing Liu on 2021/2/15.
//

#include "../include/Game.h"

/**
 * constructor of the Game class
 */
Game::Game() {
  window = 0;
  renderer = 0;
}

/**
 * destructor of the Game class
 */
Game::~Game() {}

/**
 * Initialize the game.
 *
 * return true if success, false otherwise
 */
bool Game::Init() {
  SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO);

  // Create Window
  window = SDL_CreateWindow("Breakout v1.0.0",
                            SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,
                            SCREEN_WIDTH, SCREEN_HEIGHT, SDL_WINDOW_OPENGL);
  if (!window) {
    std::cout << "Error creating window:" << SDL_GetError() << std::endl;
    return false;
  }

  // Create Renderer
  renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);
  if (!renderer) {
    std::cout << "Error creating renderer:" << SDL_GetError() << std::endl;
    return false;
  }

  // Initialize resources
  SDL_Surface* surface = IMG_Load("test.png");
  texture = SDL_CreateTextureFromSurface(renderer, surface);
  SDL_FreeSurface(surface);
  Mix_Init(0);

  // Initialize configs and language
  config = new Config();
  langData = config->LoadLanguage();

  // Initialize fonts
  TTF_Init();
  textFont = ResourceManager::getFont("./Assets/font/MSYahei.ttf", 30);

  //Initialize timing
  lastTick = SDL_GetTicks();
  fpsTick = lastTick;
  fps = 0;
  lastUpdated = 0;

  return true;
}

/**
 * Clean the game.
 */
void Game::Clean() {
  // Clean
  delete level;
  delete paddle;
  delete ball;
  delete livesText;
  delete scoreText;
  delete menu;

  SDL_DestroyTexture(texture);

  // Clean renderer and window
  SDL_DestroyRenderer(renderer);
  SDL_DestroyWindow(window);

  // Clean audio resources
  Mix_FreeChunk(wallHitSound);
  Mix_FreeChunk(brickHitSound);
  Mix_FreeMusic(bgm);
  Mix_Quit();
}

/**
 * Run the game.
 */
void Game::Run() {
  level = new Level(renderer);
  paddle = new Paddle(renderer);
  ball = new Ball(renderer);
  stage = 1;

  NewGame(stage);

  Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, 2, 2048);

//  getResource("./Assets/WallHit.wav");

  // Load audio resources from resource manager
  wallHitSound = ResourceManager::getSound("./Assets/sound/WallHit.wav");
  brickHitSound = ResourceManager::getSound("./Assets/sound/BrickHit.wav");
  bgm = ResourceManager::getMusic("./Assets/music/bgm.mp3");
  if (!bgm) {
    printf("Mix_LoadMUS(\"bgm.mp3\"): %s\n", Mix_GetError());
  }
  if (Mix_PlayMusic(bgm, -1) == -1) {
    printf("Mix_PlayMusic: %s\n", Mix_GetError());
    // well, there's no music
  }

  paused = false;
  bool running = true;
  livesText = new Text(50, 50, renderer, textFont);
  scoreText = new Text(1100, 50, renderer, textFont);
  menu = new Menu(textFont, langData);

  // Main Loop
  while (running) {
    // Handler events
    SDL_Event e;
    if (SDL_PollEvent(&e)) {
      if (e.type == SDL_QUIT) {
        running = false;
      }
      else if (e.type == SDL_KEYDOWN) {
        if (e.key.keysym.sym == SDLK_q) {
          running = false;
        }
        else if (!paused) {
          if (e.key.keysym.sym == SDLK_ESCAPE)
          {
            menu->Pause(renderer);
            menu->state = 0;
            paused = true;
          }
          else if (e.key.keysym.sym == SDLK_SPACE) {
            if (paddleStick) {
              paddleStick = false;
              ball->SetDirection(0, -1);
            }
          }
          else if (e.key.keysym.sym == SDLK_h) {
            lives++;
          }
          else if (e.key.keysym.sym == SDLK_n) {
            stage++;
            NewGame(stage);
          }
        }
        if (paused) {
          if (e.key.keysym.sym == SDLK_UP || e.key.keysym.sym == SDLK_DOWN) {
            menu->Select();
            menu->choice ^= 1;
          }
          if (e.key.keysym.sym == SDLK_SPACE || e.key.keysym.sym == SDLK_RETURN) {
            if (menu->choice == 0) {
              switch (menu->state) {
                case 0:
                  paused = false;
                  lastTick = SDL_GetTicks();
                  break;
                case 1:
                  stage++;
                  NewGame(stage);
                  paused = false;
                  break;
                case 2:
                  stage = 1;
                  NewGame(stage);
                  paused = false;
                  break;
              }
            }
            else {
              running = false;
            }
          }
        }
      }
    }

    // Calculate delta & FPS
    unsigned int curTick = SDL_GetTicks();
    unsigned int elapsed = curTick - fpsTick;
    if (elapsed < FPS_DELAY) {
      SDL_Delay(floor(FPS_DELAY - elapsed));
      curTick = SDL_GetTicks();
      elapsed = curTick - lastTick;
    }
    fps = 1000.0f / elapsed;
    fpsTick = curTick;
    char buf[100];
    float delta = (curTick - lastTick) / 1000.0f;
    // Update FPS on title twice per second
    if (fpsTick - lastUpdated > 500) {
      snprintf(buf, 100, "Breakout v1.0.0 - FPS: %u - Stage: %u", fps, stage);
      SDL_SetWindowTitle(window, buf);
      lastUpdated = fpsTick;
    }
    lastTick = curTick;

    // Update and render the game
    Update(delta);
    Render(delta);
  }

  Clean();

  SDL_Quit();
}

/**
 * Start a new game with given stage.
 *
 * @param int the stage number to start
 */
void Game::NewGame(int stageNum) {
  stage = level->LoadLevel(stageNum);
  ResetPaddle();
  lives = 3;
  score = 0;
}

/**
 * Reset paddle to initial position.
 */
void Game::ResetPaddle() {
  paddleStick = true;
  paddle->x = SCREEN_WIDTH / 2 - paddle->width / 2;
  StickBall();
}

/**
 * Stick ball to paddle.
 */
void Game::StickBall() {
  ball->x = paddle->x + paddle->width / 2 - ball->width / 2;
  ball->y = paddle->y - ball->height;
}

/**
 * Update information in the game.
 *
 * @param delta the time elapsed from last loop in seconds
 */
void Game::Update(float delta) {
  // Mouse Input
//  int mx, my;
//  uint8_t mState = SDL_GetMouseState(&mx, &my);
//  SetPaddleX(mx - paddle->width / 2.0f);
//
//  if (mState & SDL_BUTTON(1)) {
//    if (paddleStick) {
//      paddleStick = false;
//      ball->SetDirection(1, -1);
//    }
//  }

  if (!paused) {
    // Keyboard Input
    const Uint8 *keyStates = SDL_GetKeyboardState(NULL);
    if (keyStates[SDL_SCANCODE_LEFT] && keyStates[SDL_SCANCODE_RIGHT]) {
      paddle->velocity = 0;
    }
    else if (keyStates[SDL_SCANCODE_LEFT]) {
      paddle->velocity = -PADDLE_SPEED;
    }
    else if (keyStates[SDL_SCANCODE_RIGHT]) {
      paddle->velocity = PADDLE_SPEED;
    }
    else {
      paddle->velocity = 0;
    }

    CheckBoardCollisions();
    CheckPaddleCollisions();
    CheckBrickCollisions();

    if (GetBrickCount() == 0) {
      menu->Win(renderer);
      menu->state = 1;
      paused = true;
    }

    level->Update(delta);
    paddle->Update(delta);
    SetPaddleX(paddle->x);

    if (paddleStick) {
      StickBall();
    }

    if (!paddleStick) {
      ball->Update(delta);
    }
  }
}

/**
 * Set paddle to the x position.
 *
 * @param x the x position of paddle
 */
void Game::SetPaddleX(float x) {
  float newX;
  if (x < level->x) {
    // Upper bound
    newX = level->x;
  } else if (x + paddle->width > level->x + level->width) {
    // Lower bound
    newX = level->x + level->width - paddle->width;
  } else {
    newX = x;
  }
  paddle->x = newX;
}

/**
 * Check if ball collides with the frame of the stage.
 */
void Game::CheckBoardCollisions() {
  // Top and bottom collisions
  if (ball->y < level->y) {
    // Top: keep the ball and reflect the y-dir
    ball->y = level->y;
    ball->dirY *= -1;
    Mix_PlayChannel(-1, wallHitSound, 0);
  } else if (ball->y + ball->height > level->y + level->height) {
    // Bottom: ball lost
    ResetPaddle();
    lives--;
    if (lives == 0) {
      menu->Lose(renderer);
      menu->state = 2;
      paused = true;
    }
  }

  // Left and right collisions
  if (ball->x <= level->x) {
    // Left: keep the ball and reflect the x-dir
    ball->x = level->x;
    ball->dirX *= -1;
    Mix_PlayChannel(-1, wallHitSound, 0);
  } else if (ball->x + ball->width >= level->x + level->width) {
    // Right: keep the ball and reflect the x-dir
    ball->x = level->x + level->width - ball->width;
    ball->dirX *= -1;
    Mix_PlayChannel(-1, wallHitSound, 0);
  }
}

/**
 * Set the new direction of the ball if collides with paddle.
 *
 * @return the new direction of the ball in x-axis
 */
float Game::GetReflection(float hitX) {
  // Make sure the hitX variable is within the width of the paddle
  if (hitX < 0) {
    hitX = 0;
  } else if (hitX > paddle->width) {
    hitX = paddle->width;
  }

  // Everything left of the center of the paddle is reflected to the left
  // while everything right is reflected to the right
  hitX -= paddle->width / 2.0f;

  // Scale the reflection, making it fall in the range -2.0f to 2.0f
  return 2.0f * (hitX / (paddle->width / 2.0f));
}

/**
 * Check if ball collides with the paddle.
 */
void Game::CheckPaddleCollisions() {
  // Get the center x-coordinate of the ball
  float ballCenterX = ball->x + ball->width / 2.0f;

  // Check paddle collision
  if (ball->Collides(paddle)) {
    ball->y = paddle->y - ball->height;
    ball->SetDirection(GetReflection(ballCenterX - paddle->x), -1);
    Mix_PlayChannel(-1, wallHitSound, 0);
  }
}

//void Game::CheckBrickCollisions() {
//  for (int i = 0; i < BRICK_ROW; i++) {
//    for (int j = 0; j <BRICK_COL; j++) {
//      Brick brick = level->bricks[i][j];
//
//      // Check if brick is present
//      if (brick.state) {
//        // Brick x and y coordinates
//        float brickX = level->brickOffsetX + level->x + i * BRICK_WIDTH;
//        float brickY = level->brickOffsetY + level->y + j * BRICK_HEIGHT;
//
//        float w = 0.5f * (ball->width + BRICK_WIDTH);
//        float h = 0.5f * (ball->height + BRICK_HEIGHT);
//        float dx = (ball->x + 0.5f * ball->width) - (brickX + 0.5f * BRICK_WIDTH);
//        float dy = (ball->y + 0.5f * ball->height) - (brickY + 0.5f * BRICK_HEIGHT);
//
//        if (fabs(dx) <= w && fabs(dy) <= h) {
//          // Collision detected
//          level->bricks[i][j].state = false;
//
//          float wy = w * dy;
//          float hx = h * dx;
//
//          if (wy > hx) {
//            if (wy > -hx) {
//              // Bottom (y is flipped)
//              BallBrickResponse(3);
//            } else {
//              // Left
//              BallBrickResponse(0);
//            }
//          } else {
//            if (wy > -hx) {
//              // Right
//              BallBrickResponse(2);
//            } else {
//              // Top (y is flipped)
//              BallBrickResponse(1);
//            }
//          }
//          return;
//        }
//      }
//    }
//  }
//}

/**
 * Check if ball collides with bricks.
 */
void Game::CheckBrickCollisions() {
  for (int i = 0; i < BRICK_ROW; i++) {
    for (int j = 0; j <BRICK_COL; j++) {
      Brick brick = level->bricks[i][j];

      // Check if brick is present
      if (brick.state) {
        // Brick x and y coordinates
        float brickX = level->brickOffsetX + level->x + i * BRICK_WIDTH;
        float brickY = level->brickOffsetY + level->y + j * BRICK_HEIGHT;

        // Center of the ball x and y coordinates
        float ballCenterX = ball->x + 0.5f * ball->width;
        float ballCenterY = ball->y + 0.5f * ball->height;

        // Center of the brick x and y coordinates
        float brickCenterX = brickX + 0.5f * BRICK_WIDTH;
        float brickCenterY = brickY + 0.5f * BRICK_HEIGHT;

        if (ball->x <= brickX + BRICK_WIDTH
        && ball->x + ball->width >= brickX
        && ball->y <= brickY + BRICK_HEIGHT
        && ball->y + ball->height >= brickY)
        {
          // Collision detected, remove the brick
          level->bricks[i][j].state = false;

          // Assume the ball goes slow enough to not skip through the bricks

          // Calculate ySize
          float yMin = 0;
          if (brickY > ball->y) {
            yMin = brickY;
          } else {
            yMin = ball->y;
          }

          float yMax = 0;
          if (brickY + BRICK_HEIGHT < ball->y + ball->height) {
            yMax = brickY + BRICK_HEIGHT;
          } else {
            yMax = ball->y + ball->height;
          }
          float ySize = yMax - yMin;

          // Calculate xSize
          float xMin = 0;
          if (brickX > ball->x) {
            xMin = brickX;
          } else {
            xMin = ball->x;
          }

          float xMax = 0;
          if (brickX + BRICK_WIDTH < ball->x + ball->width) {
            xMax = brickX + BRICK_WIDTH;
          } else {
            xMax = ball->x + ball->width;
          }
          float xSize = xMax - xMin;

          // The origin is at the top-left corner of the screen
          // Set collision response
          if (xSize > ySize) {
            if (ballCenterY > brickCenterY) {
              // Bottom
              ball->y += ySize + 0.01f; // Move out of collision
              BallBrickResponse(3);
            } else {
              // Top
              ball->y -= ySize + 0.01f; // Move out of collision
              BallBrickResponse(1);
            }
          } else {
            if (ballCenterX < brickCenterX) {
              // Left
              ball->x -= xSize + 0.01f; // Move out of collision
              BallBrickResponse(0);
            } else {
              // Right
              ball->x += xSize + 0.01f; // Move out of collision
              BallBrickResponse(2);
            }
          }

          return;
        }
      }
    }
  }
}

/**
 * Set the new direction of the ball if collides with bricks.
 */
void Game::BallBrickResponse(int dirIndex) {
  //dirIndex 0: Left, 1: Top, 2: Right, 3: Bottom

  // Direction factors
  int mulX = 1;
  int mulY = 1;

  if (ball->dirX > 0) {
    // Ball is moving in the positive x direction
    if (ball->dirY > 0) {
      // Ball is moving in the positive y direction
      // +1 +1
      if (dirIndex == 0 || dirIndex == 3) {
        mulX = -1;
      } else {
        mulY = -1;
      }
    } else if (ball->dirY < 0) {
      // Ball is moving in the negative Y direction
      // +1 -1
      if (dirIndex == 0 || dirIndex == 1) {
        mulX = -1;
      } else {
        mulY = -1;
      }
    }
  } else if (ball->dirX < 0) {
    // Ball is moving in the negative x direction
    if (ball->dirY > 0) {
      // Ball is moving in the positive y direction
      // -1 +1
      if (dirIndex == 2 || dirIndex == 3) {
        mulX = -1;
      } else {
        mulY = -1;
      }
    } else if (ball->dirY < 0) {
      // Ball is moving in the negative y direction
      // -1 -1
      if (dirIndex == 1|| dirIndex == 2) {
        mulX = -1;
      } else {
        mulY = -1;
      }
    }
  } else if (ball->dirX == 0) {
    // Ball is reflected in the y direction
    mulY = -1;
    }

  // Set the new direction of the ball, by multiplying the old direction
  // with the determined direction factors
  ball->SetDirection(mulX * ball->dirX, mulY * ball->dirY);
  score += 200;
  Mix_PlayChannel(-1, brickHitSound, 0);
}

/**
 * Count the number of bricks left on stage.
 *
 * @return brickCount the number of bricks left on stage
 */
int Game::GetBrickCount() {
  int brickCount = 0;
  for (int i = 0; i < BRICK_ROW; i++) {
    for (int j = 0; j < BRICK_COL; j++) {
      Brick brick = level->bricks[i][j];
      if (brick.state) {
        brickCount++;
      }
    }
  }

  return brickCount;
}

/**
 * Render the game on screen.
 *
 * @param delta the time elapsed from last loop in seconds
 */
void Game::Render(float delta) {
  SDL_SetRenderDrawColor(renderer, 0x0, 0x0, 0x0, 0xFF);
  SDL_RenderClear(renderer);

  if (paused) {
    menu->Draw(renderer);
  }
  else {
    livesText->SetLives(lives, langData);
    livesText->Draw();

    scoreText->SetScore(score, langData);
    scoreText->Draw();

    level->Render(delta);
    paddle->Render(delta);
    ball->Render(delta);
  }

  SDL_RenderPresent(renderer);
}



