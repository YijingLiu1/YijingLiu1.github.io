//
// Created by Yijing Liu on 2021/2/17.
//

#include "../include/StageCache.h"

/**
 * constructor of the StageCache class
 */
StageCache::StageCache() {
}

/**
 * destructor of the StageCache class
 */
StageCache::~StageCache() {
  clearStage();
}

/**
 * Load the stage into cache.
 *
 * @param resourcePath the resource path for the stage file
 */
void StageCache::LoadStage(const char* resourcePath) {
  // Make brick data as value
  std::ifstream fStream(resourcePath);
  std::string line;
  std::vector<std::vector<unsigned int>> brickData;
  int type;
  if (fStream) {
    while (std::getline(fStream, line)) {
      std::istringstream sStream(line);
      std::vector<unsigned int> row;
      while (sStream >> type) {
        row.push_back(type);
      }
      brickData.push_back(row);
    }
  }

  // Make stage number as key
  int stage;
  char stageChar[10];
  _splitpath_s(resourcePath, NULL, 0, NULL, 0, stageChar, 10, NULL, 0);
  std::stringstream ss;
  ss << stageChar;
  ss >> stage;

  // Insert it into the map
  _resourceMap.insert(std::make_pair(stage, brickData));
}

/**
 * Get the stage from cache.
 *
 * @param int the stage number to get
 * @return the vector of the info of stage
 */
std::vector<std::vector<unsigned int>> StageCache::GetStage(int stage) {
  // look up and see if in the map
  auto mit = _resourceMap.find(stage);

  // check if not in the map
  if (mit == _resourceMap.end()) {
//    SDL_Log("Can't find given stage number, use stage 1 instead..");
    return notFound;
  }

//  SDL_Log("Found allocated stage!");
  return mit->second;
}

/**
 * Clear the stage cache.
 */
void StageCache::clearStage() {
  while (_resourceMap.begin() != _resourceMap.end())
  {
    _resourceMap.erase(_resourceMap.begin());
  }
  SDL_Log("Clearing allocated stages..");
}
