//
// Created by Yijing Liu on 2021/2/15.
//

#include "../include/Ball.h"

/**
 * constructor of the Ball class
 *
 * @param renderer the SDL renderer
 */
Ball::Ball(SDL_Renderer* renderer): Entity(renderer) {
  // Load texture from resource manager
  texture = ResourceManager::getTexture(renderer, "./Assets/image/ball.png");

  x = 0;
  y = 0;
  width = 24;
  height = 24;

  SetDirection(1, 1);
}

/**
 * destructor of the Ball class
 */
Ball::~Ball() {
  // Clean resources
  SDL_DestroyTexture(texture);
}

/**
 * Update the position of the ball.
 *
 * @param delta the time elapsed from last loop in seconds
 */
void Ball::Update(float delta) {
  x += dirX * delta;
  y += dirY * delta;
}

/**
 * Render the ball on the screen.
 *
 * @param delta the time elapsed from last loop in seconds
 */
void Ball::Render(float delta) {
  SDL_Rect rect;
  rect.x = (int)(x + 0.5f);
  rect.y = (int)(y + 0.5f);
  rect.w = width;
  rect.h = height;
  SDL_RenderCopy(renderer, texture, 0, &rect);
}

/**
 * Normalize the direction vector and multiply with BALL_SPEED.
 *
 * @param dirX the direction vector in x-axis
 * @param dirY the direction vector in y-axis
 */
void Ball::SetDirection(float dirX, float dirY) {
  // Normalize the direction vector and multiply with BALL_SPEED
  float length = sqrt(dirX * dirX + dirY * dirY);
  this->dirX = BALL_SPEED * (dirX / length);
  this->dirY = BALL_SPEED * (dirY / length);
}