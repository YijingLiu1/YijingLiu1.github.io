//
// Created by Yijing Liu on 2021/2/15.
//

#include "../include/Level.h"

/**
 * constructor of the Level class
 *
 * @param renderer the SDL renderer
 */
Level::Level(SDL_Renderer* renderer): Entity(renderer) {
  // Load textures from resource manager
  brickTexture = ResourceManager::getTexture(renderer, "./Assets/image/bricks.png");
  frameTexture = ResourceManager::getTexture(renderer, "./Assets/image/side.png");

  // Load stages from resource manager

  _finddata_t stage;
  long lf;
  char address[30];
  const char *dir = "./Assets/stage/";
  if ((lf = _findfirst("./Assets/stage/*.txt*", &stage)) == -1) {
    SDL_Log("Stage file not found!");
  }
  else {
    do {
      strcpy_s(address, dir);
      strcat_s(address, (char*)stage.name);
      ResourceManager::loadStage((char*)address);
    } while (_findnext(lf, &stage) == 0);
  }
  _findclose(lf);


  srand(time(0));

  x = 216;
  y = 0;
  width = 848;
  height = 720;

  brickOffsetX = 40;
  brickOffsetY = 40;
}

/**
 * destructor of the Level class
 */
Level::~Level() {
  // Clean resources
  SDL_DestroyTexture(brickTexture);
  SDL_DestroyTexture(frameTexture);
}

/**
 * Update the position of the level.
 *
 * @param delta the time elapsed from last loop in seconds
 */
void Level::Update(float delta) {}

/**
 * Render the level on the screen.
 *
 * @param delta the time elapsed from last loop in seconds
 */
void Level::Render(float delta) {
  // Render bricks
  for (int i = 0; i < BRICK_ROW; i++) {
    for (int j = 0; j < BRICK_COL; j++) {
      Brick brick = bricks[i][j];

      // Check if the brick exists
      if (!brick.state) continue;

      SDL_Rect srcRect;

      srcRect.x = (brick.type % 2) * BRICK_WIDTH;
      srcRect.y = (brick.type / 2) * BRICK_HEIGHT;
      srcRect.w = BRICK_WIDTH;
      srcRect.h = BRICK_HEIGHT;

      SDL_Rect dstRect;
      dstRect.x = brickOffsetX + x + i * BRICK_WIDTH;
      dstRect.y = brickOffsetY + y + j * BRICK_HEIGHT;
      dstRect.w = BRICK_WIDTH;
      dstRect.h = BRICK_HEIGHT;

      SDL_RenderCopy(renderer, brickTexture, &srcRect, &dstRect);
    }
  }

  // Render frames
  SDL_Rect dstRect;
  dstRect.x = 200;
  dstRect.y = 0;
  dstRect.w = 16;
  dstRect.h = 720;
  SDL_RenderCopy(renderer, frameTexture, 0, &dstRect);

  dstRect.x = 1064;
  dstRect.y = 0;
  dstRect.w = 16;
  dstRect.h = 720;
  SDL_RenderCopy(renderer, frameTexture, 0, &dstRect);
}

/**
 * Load the level data.
 *
 * @param int the stage number to load
 * @return stage the stage number loaded
 */
int Level::LoadLevel(int stage) {
  std::vector<std::vector<unsigned int>> brickData;
  brickData = ResourceManager::getStage(stage);

  // if stage out of range, go back to stage 1
  if (brickData.size() <= 0) {
    stage = 1;
    brickData = ResourceManager::getStage(stage);
  }

  for (int i = 0; i < BRICK_ROW; i++) {
    for (int j = 0; j < BRICK_COL; j++) {
      Brick brick;

      brick.type = rand() % 4;
      if (brickData[i][j]) {
        brick.state = true;
      }
      else {
        brick.state = false;
      }
      bricks[i][j] = brick;
    }
  }

  return stage;
}
