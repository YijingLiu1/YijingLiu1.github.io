//
// Created by Yijing Liu on 2021/2/15.
//

#include "../include/Paddle.h"

/**
 * constructor of the Paddle class
 *
 * @param renderer the SDL renderer
 */
Paddle::Paddle(SDL_Renderer* renderer): Entity(renderer) {
  // Load texture from resource manager
  texture = ResourceManager::getTexture(renderer, "./Assets/image/paddle.png");

  width = 128;
  height = 32;
  x = 576;
  y = 680;
  velocity = 0;
}

/**
 * destructor of the Paddle class
 */
Paddle::~Paddle() {
  // Clean resources
  SDL_DestroyTexture(texture);
}

/**
 * Update the position of the paddle.
 *
 * @param delta the time elapsed from last loop in seconds
 */
void Paddle::Update(float delta) {
  x += velocity * delta;
}

/**
 * Render the paddle on the screen.
 *
 * @param delta the time elapsed from last loop in seconds
 */
void Paddle::Render(float delta) {
  SDL_Rect rect;
  rect.x = (int)(x + 0.5f);
  rect.y = (int)(y + 0.5f);
  rect.w = width;
  rect.h = height;
  SDL_RenderCopy(renderer, texture, 0, &rect);
}