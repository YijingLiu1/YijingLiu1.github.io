//
// Created by Yijing Liu on 2021/2/17.
//

#include "../include/TextureCache.h"

/**
 * constructor of the TextureCache class
 */
TextureCache::TextureCache() {}

/**
 * destructor of the TextureCache class
 */
TextureCache::~TextureCache() {
  clearTexture();
}

/**
 * Get the texture from cache.
 *
 * @param renderer the SDL renderer
 * @param resourcePath the resource path for the texture
 * @return the SDL_Texture file pointer of the texture
 */
SDL_Texture* TextureCache::getTexture(SDL_Renderer* renderer, const char* resourcePath) {
  // look up and see if in the map
  auto mit = _resourceMap.find(resourcePath);

  // check if not in the map
  if (mit == _resourceMap.end()) {
    // Load the resource
    SDL_Surface* surface = IMG_Load(resourcePath);
    SDL_Texture* newResource = SDL_CreateTextureFromSurface(renderer, surface);
    SDL_FreeSurface(surface);

    if(newResource==NULL){
      SDL_Log("Failed to allocate texture..");
      return newResource;
    }else{
      SDL_Log("Allocating new texture..");
    }

    // Insert it into the map
    _resourceMap.insert(std::make_pair(resourcePath, newResource));

    return newResource;
  }

  SDL_Log("Loading from already allocated textures..");
  return mit->second;
}

/**
 * Clear the texture cache.
 */
void TextureCache::clearTexture() {
  while (_resourceMap.begin() != _resourceMap.end())
  {
    _resourceMap.erase(_resourceMap.begin());
  }
  SDL_Log("Clearing allocated textures..");
}
