//
// Created by Yijing Liu on 2021/2/15.
//

#include "../include/Game.h"

/**
 * Main function of the program.
 *
 * @param argc argument count
 * @param argv argument vector
 * @return 0
 */
int main(int argc, char** argv)
{
  Game myGame;
  if (myGame.Init()) {
    myGame.Run();
  }

  return 0;
}

