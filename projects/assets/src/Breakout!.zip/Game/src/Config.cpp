//
// Created by Yijing Liu on 2021/2/17.
//

#include "../include/Config.h"

/**
 * constructor of the Config class
 */
Config::Config() {
  // Read from config
  std::ifstream fStream("./config.cfg");
  std::string line;
  if (fStream) {
    while (std::getline(fStream, line)) {
      std::istringstream sStream(line);
      std::string key;
      if (std::getline(sStream, key, '=')) {
        std::string value;
        if (std::getline(sStream, value)) {
          _configMap.insert(std::make_pair(key, value));
        }
      }
    }
  }
}

/**
 * destructor of the Config class
 */
Config::~Config() {}

/**
 * Load language for the game
 * according to the configuration.
 *
 * @return landData the vector for game texts in requested language
 */
std::vector<std::string> Config::LoadLanguage() {
  // Find setting for language
  auto mit = _configMap.find("Language");

  std::ifstream fStream;
  if (mit == _configMap.end() || strcmp(mit->second.c_str(), "sc") != 0) {
    // If not found, use English
    fStream.open("./Assets/lang/en.txt");
  }
  else {
    fStream.open("./Assets/lang/sc.txt");
  }

  std::string line;
  std::vector<std::string> langData;
  if (fStream) {
    while (std::getline(fStream, line)) {
      std::istringstream sStream(line);
      std::string text;
      if (std::getline(sStream, text)) {
        langData.push_back(text);
      }
    }
  }
  return langData;
}
