//
// Created by Yijing Liu on 2021/2/15.
//

#include "../include/Entity.h"

/**
 * constructor of the Entity class
 *
 * @param renderer the SDL renderer
 */
Entity::Entity(SDL_Renderer* renderer) {
  this->renderer = renderer;

  x = 0;
  y = 0;
  width = 1;
  height = 1;
}

/**
 * virtual destructor of the Entity class
 */
Entity::~Entity() {}

/**
 * Update the position of the entity (virtual).
 *
 * @param delta the time elapsed from last loop in seconds
 */
void Entity::Update(float delta) {}

/**
 * Render the entity on the screen (virtual).
 *
 * @param delta the time elapsed from last loop in seconds
 */
void Entity::Render(float delta) {}

/**
 * Check if two entities collide.
 *
 * @param other the other entity
 * @return true if collide, false otherwise
 */
bool Entity::Collides(Entity* other) {
  if (x + width > other->x && x < other->x + other->width &&
  y + height > other->y && y < other->y + other->height) {
    return true;
  }
  return false;
}
