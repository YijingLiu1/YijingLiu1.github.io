//
// Created by Yijing Liu on 2021/2/17.
//

#include "../include/SoundCache.h"

/**
 * constructor of the SoundCache class
 */
SoundCache::SoundCache() {}

/**
 * destructor of the SoundCache class
 */
SoundCache::~SoundCache() {
  clearSound();
}

/**
 * Get the sound from cache.
 *
 * @param resourcePath the resource path for the sound
 * @return the Mix_Chunk file pointer of the sound
 */
Mix_Chunk* SoundCache::getSound(const char* resourcePath) {
  // look up and see if in the map
  auto mit = _resourceMap.find(resourcePath);

  // check if not in the map
  if (mit == _resourceMap.end()) {
    // Load the resource
    Mix_Chunk* newResource = Mix_LoadWAV(resourcePath);

    if(newResource==NULL){
      SDL_Log("Failed to allocate sound..");
      return newResource;
    }else{
      SDL_Log("Allocating new sound..");
    }

    // Insert it into the map
    _resourceMap.insert(std::make_pair(resourcePath, newResource));

    return newResource;
  }

  SDL_Log("Loading from already allocated sounds..");
  return mit->second;
}

/**
 * Clear the sound cache.
 */
void SoundCache::clearSound() {
  while (_resourceMap.begin() != _resourceMap.end())
  {
    _resourceMap.erase(_resourceMap.begin());
  }
  SDL_Log("Clearing allocated sounds..");
}
