//
// Created by Yijing Liu on 2021/2/15.
//

#ifndef MONOREPO_YIJINGLIU1_BALL_H
#define MONOREPO_YIJINGLIU1_BALL_H

#include "Entity.h"

#include <math.h>

/** Define a ball speed in pixels per second */
const float BALL_SPEED = 500;

/**
 * Ball.h
 *
 * This class provides information about
 * the ball in the Breakout! gameplay,
 * derived from the Entity class.
 *
 * @author Yijing Liu
 * @since 2021-02-15
 */
class Ball: public Entity {
public:
    /**
     * constructor of the Ball class
     *
     * @param renderer the SDL renderer
     */
    Ball(SDL_Renderer* renderer);

    /**
     * destructor of the Ball class
     */
    ~Ball();

    /**
     * Update the position of the ball.
     *
     * @param delta the time elapsed from last loop in seconds
     */
    void Update(float delta);

    /**
     * Render the ball on the screen.
     *
     * @param delta the time elapsed from last loop in seconds
     */
    void Render(float delta);

    /**
     * Normalize the direction vector and multiply with BALL_SPEED.
     *
     * @param dirX the direction vector in x-axis
     * @param dirY the direction vector in y-axis
     */
    void SetDirection(float dirX, float dirY);

    /** the direction vector in x-axis, y-axis */
    float dirX, dirY;

private:
    /** the SDL texture for the ball */
    SDL_Texture* texture;
};


#endif //MONOREPO_YIJINGLIU1_BALL_H
