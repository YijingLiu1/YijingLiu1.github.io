//
// Created by Yijing Liu on 2021/2/16.
//

#ifndef MONOREPO_YIJINGLIU1_TEXT_H
#define MONOREPO_YIJINGLIU1_TEXT_H

// ==================== Libraries ==================
// Depending on the operating system we use
// The paths to SDL are actually different.
// The #define statement should be passed in
// when compiling using the -D argument.
// This gives an example of how a programmer
// may support multiple platforms with different
// dependencies.
#if defined(LINUX) || defined(MINGW)
#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>
#include <SDL2/SDL_mixer.h>
#include <SDL2/SDL_image.h>
#else
// Windows and Mac use a different path
// If you have compilation errors, change this as needed.
#include <SDL.h>
#include <SDL_ttf.h>
#include <SDL_mixer.h>
#include <SDL_image.h>
#endif

#include "Config.h"

// ==================== Libraries ==================

/**
 * Text.h
 *
 * This class provides information about
 * the texts displayed in the Breakout! gameplay.
 *
 * @author Yijing Liu
 * @since 2021-02-16
 */
class Text {
public:
    /**
     * constructor of the Text class
     *
     * @param x the x position of the text
     * @param y the y position of the text
     * @param renderer the SDL renderer
     * @param font the font for the menu
     */
    Text(int x, int y, SDL_Renderer* renderer, TTF_Font* font);

    /**
     * destructor of the Text class
     */
    ~Text();

    /**
     * Render texts in the game stage.
     */
    void Draw();

    /**
     * Set score info in the text.
     */
    void SetScore(int score, std::vector<std::string> langData);

    /**
     * Set lives info in the text.
     */
    void SetLives(int lives, std::vector<std::string> langData);

    /** the SDL renderer for the text */
    SDL_Renderer* renderer;
    /** the TTF font for the text */
    TTF_Font* font;
    /** the SDL surface for the text */
    SDL_Surface* surface{};
    /** the SDL texture for the text */
    SDL_Texture* texture{};
    /** the SDL rectangle for the text */
    SDL_Rect rect{};
};



#endif //MONOREPO_YIJINGLIU1_TEXT_H
