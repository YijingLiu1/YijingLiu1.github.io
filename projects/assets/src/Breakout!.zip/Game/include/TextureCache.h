//
// Created by Yijing Liu on 2021/2/17.
//

#ifndef MONOREPO_YIJINGLIU1_TEXTURECACHE_H
#define MONOREPO_YIJINGLIU1_TEXTURECACHE_H

#include <map>
#include <string>
#include <iterator>


#if defined(LINUX) || defined(MINGW)
#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#else
// Windows and Mac use a different path
// If you have compilation errors, change this as needed.
#include <SDL.h>
#include <SDL_image.h>
#endif

/**
 * TextureCache.h
 *
 * This class provides information about
 * the TextureCache class for game resource,
 * storing cache for textures.
 *
 * @author Yijing Liu
 * @since 2021-02-17
 */
class TextureCache {
public:
    /**
     * constructor of the TextureCache class
     */
    TextureCache();

    /**
     * destructor of the TextureCache class
     */
    ~TextureCache();

    /**
     * Get the texture from cache.
     *
     * @param renderer the SDL renderer
     * @param resourcePath the resource path for the texture
     * @return the SDL_Texture file pointer of the texture
     */
    SDL_Texture* getTexture(SDL_Renderer* renderer, const char* resourcePath);

    /**
     * Clear the texture cache.
     */
    void clearTexture();

private:
    /** the map storing textures */
    std::map<const char*, SDL_Texture*> _resourceMap;
};


#endif //MONOREPO_YIJINGLIU1_TEXTURECACHE_H
