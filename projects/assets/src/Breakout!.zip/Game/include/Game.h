//
// Created by Yijing Liu on 2021/2/15.
//

#ifndef MONOREPO_YIJINGLIU1_GAME_H
#define MONOREPO_YIJINGLIU1_GAME_H

// ==================== Libraries ==================
// Depending on the operating system we use
// The paths to SDL are actually different.
// The #define statement should be passed in
// when compiling using the -D argument.
// This gives an example of how a programmer
// may support multiple platforms with different
// dependencies.
#if defined(LINUX) || defined(MINGW)
#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>
#include <SDL2/SDL_mixer.h>
#include <SDL2/SDL_image.h>
#else
// Windows and Mac use a different path
// If you have compilation errors, change this as needed.
#include <SDL.h>
#include <SDL_ttf.h>
#include <SDL_mixer.h>
#include <SDL_image.h>
#endif

#include "Ball.h"
#include "Level.h"
#include "Paddle.h"
#include "Text.h"
#include "Menu.h"
#include "ResourceManager.h"

// C and C++ Libraries
#include <stdio.h>
#include <iostream>
#include <string>
#include <chrono>
// ==================== Libraries ==================

#define FPS_DELAY 16.666f

/**
 * Game.h
 *
 * This class provides information about
 * the initialization, execution and cleaning
 * of the Breakout! gameplay.
 *
 * @author Yijing Liu
 * @since 2021-02-15
 */
class Game {
public:
    /**
     * constructor of the Game class
     */
    Game();

    /**
     * destructor of the Game class
     */
    ~Game();

    /**
     * Initialize the game.
     *
     * return true if success, false otherwise
     */
    bool Init();

    /**
     * Run the game.
     */
    void Run();

private:
    /** the SDL window for the game */
    SDL_Window* window;
    /** the SDL renderer for the game */
    SDL_Renderer* renderer;
    /** the SDL texture for the game */
    SDL_Texture* texture;

    /** the timing variables for the game */
    unsigned int lastTick, fpsTick, fps, lastUpdated;

    /** the level for the game */
    Level* level;
    /** the paddle for the game */
    Paddle* paddle;
    /** the ball for the game */
    Ball* ball;
    /** the font for the game */
    TTF_Font* textFont;
    /** true if ball stick to paddle */
    bool paddleStick;

    /** true if game paused */
    bool paused;
    /** number of lives left */
    int lives;
    /** number of the current score */
    int score;
    /** number of the current stage */
    int stage;

    /** text for displaying lives */
    Text* livesText;
    /** text for displaying score */
    Text* scoreText;
    /** menu for the game */
    Menu* menu;
    /** config for the game */
    Config* config;

    /** background music for the game */
    Mix_Music* bgm;
    /** wall hit sound for the game */
    Mix_Chunk* wallHitSound;
    /** brick hit sound for the game */
    Mix_Chunk* brickHitSound;
    /** the vector for game texts in requested language */
    std::vector<std::string> langData;

    /**
     * Clean the game.
     */
    void Clean();

    /**
     * Update information in the game.
     *
     * @param delta the time elapsed from last loop in seconds
     */
    void Update(float delta);

    /**
     * Render the game on screen.
     *
     * @param delta the time elapsed from last loop in seconds
     */
    void Render(float delta);

    /**
     * Start a new game with given stage.
     *
     * @param int the stage number to start
     */
    void NewGame(int stage);

    /**
     * Reset paddle to initial position.
     */
    void ResetPaddle();

    /**
     * Stick ball to paddle.
     */
    void StickBall();

    /**
     * Set paddle to the x position.
     *
     * @param x the x position of paddle
     */
    void SetPaddleX(float x);

    /**
     * Check if ball collides with the frame of the stage.
     */
    void CheckBoardCollisions();

    /**
     * Set the new direction of the ball if collides with paddle.
     *
     * @return the new direction of the ball in x-axis
     */
    float GetReflection(float hitX);

    /**
     * Check if ball collides with the paddle.
     */
    void CheckPaddleCollisions();

    /**
     * Check if ball collides with bricks.
     */
    void CheckBrickCollisions();

    /**
     * Set the new direction of the ball if collides with bricks.
     */
    void BallBrickResponse(int dirIndex);

    /**
     * Count the number of bricks left on stage.
     *
     * @return brickCount the number of bricks left on stage
     */
    int GetBrickCount();
};


#endif //MONOREPO_YIJINGLIU1_GAME_H
