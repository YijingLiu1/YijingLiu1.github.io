//
// Created by Yijing Liu on 2021/2/15.
//

#ifndef MONOREPO_YIJINGLIU1_LEVEL_H
#define MONOREPO_YIJINGLIU1_LEVEL_H

#include "Entity.h"
#include "ResourceManager.h"
#include <stdlib.h>
#include <time.h>
#include <fstream>
#include <sstream>
#include <string>
#include <io.h>

/**
 * Brick
 *
 * This class provides information about
 * the brick in the Breakout! gameplay.
 *
 * @author Yijing Liu
 * @since 2021-02-15
 */
class Brick {
public:
    int type;
    bool state;
};

/**
 * Level.h
 *
 * This class provides information about
 * the level in the Breakout! gameplay,
 * derived from the Entity class.
 *
 * @author Yijing Liu
 * @since 2021-02-15
 */
class Level: public Entity {
public:
    /**
     * constructor of the Level class
     *
     * @param renderer the SDL renderer
     */
    Level(SDL_Renderer* renderer);

    /**
     * destructor of the Level class
     */
    ~Level();

    /**
     * Update the position of the level.
     *
     * @param delta the time elapsed from last loop in seconds
     */
    void Update(float delta);

    /**
     * Render the level on the screen.
     *
     * @param delta the time elapsed from last loop in seconds
     */
    void Render(float delta);

    /**
     * Load the level data.
     *
     * @param int the stage number to load
     * @return stage the stage number loaded
     */
    int LoadLevel(int stage);

    /** the offset of bricks from level start point in x, y */
    float brickOffsetX, brickOffsetY;

    /** Define the two-dimensional array of bricks */
    Brick bricks[BRICK_ROW][BRICK_COL];

private:
    /** the SDL texture for the brick */
    SDL_Texture* brickTexture;

    /** the SDL texture for the frame of the stage */
    SDL_Texture* frameTexture;
};


#endif //MONOREPO_YIJINGLIU1_LEVEL_H
