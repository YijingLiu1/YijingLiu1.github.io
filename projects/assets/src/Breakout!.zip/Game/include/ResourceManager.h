//
// Created by Yijing Liu on 2021/2/16.
//

#ifndef MONOREPO_YIJINGLIU1_RESOURCEMANAGER_H
#define MONOREPO_YIJINGLIU1_RESOURCEMANAGER_H

#if defined(LINUX) || defined(MINGW)
#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>
#include <SDL2/SDL_mixer.h>
#include <SDL2/SDL_image.h>
#else
// Windows and Mac use a different path
// If you have compilation errors, change this as needed.
#include <SDL.h>
#include <SDL_ttf.h>
#include <SDL_mixer.h>
#include <SDL_image.h>
#endif

// I recommend a map for filling in the resource manager
#include <map>
#include <string>
#include <memory>
#include <iterator>
#include <iostream>
#include <stdlib.h>

#include "TextureCache.h"
#include "SoundCache.h"
#include "MusicCache.h"
#include "FontCache.h"
#include "StageCache.h"

/**
 * ResourceManager.h
 *
 * This class provides information about
 * the ResourceManager class for game resource,
 * managing game resources.
 *
 * @author Yijing Liu
 * @since 2021-02-16
 */
class ResourceManager{
private:
    /**
     * constructor of the ResourceManager class
     */
    ResourceManager();  // Private Singleton

    /**
     * copy constructor of the ResourceManager class
     */
    ResourceManager(ResourceManager const&); // Avoid copy constructor

    /**
     * assignment operator of the ResourceManager class
     */
    void operator=(ResourceManager const&); // Don't allow assignment.

    /**
     * destructor of the ResourceManager class
     */
    ~ResourceManager();

    /** the singleton instance */
    static ResourceManager* instance_;
    /** the cache storing textures */
    static TextureCache _textureCache;
    /** the cache storing sounds */
    static SoundCache _soundCache;
    /** the cache storing musics */
    static MusicCache _musicCache;
    /** the cache storing fonts */
    static FontCache _fontCache;
    /** the cache storing stages */
    static StageCache _stageCache;

public:
    /**
     * get instance of the ResourceManager class
     *
     * @return the instance of ResourceManager
     */
    static ResourceManager &getInstance()
    {
      if (instance_ == NULL)
      {
        instance_ = new ResourceManager;
      }
      return *instance_;
    };

    /**
     * 'equivalent' to constructor
     */
    int startUp();

    /**
     * 'equivalent' to destructor
     */
    int shutDown();

    /**
     * Get the texture from TextureCache.
     *
     * @param renderer the SDL renderer
     * @param resourcePath the resource path for the texture
     * @return the SDL_Texture file pointer of the texture
     */
    static SDL_Texture* getTexture(SDL_Renderer* renderer, const char* resourcePath);

    /**
     * Get the sound from SoundCache.
     *
     * @param resourcePath the resource path for the sound
     * @return the Mix_Chunk file pointer of the sound
     */
    static Mix_Chunk* getSound(const char* resourcePath);

    /**
     * Get the music from MusicCache.
     *
     * @param resourcePath the resource path for the music
     * @return the Mix_Music file pointer of the music
     */
    static Mix_Music* getMusic(const char* resourcePath);

    /**
     * Get the font from FontCache.
     *
     * @param resourcePath the resource path for the font
     * @param size the font size
     * @return the TTF_Font file pointer of the font and size
     */
    static TTF_Font* getFont(const char* resourcePath, int size);

    /**
     * Load the stage into StageCache.
     *
     * @param resourcePath the resource path for the stage file
     */
    static void loadStage(const char* resourcePath);

    /**
     * Get the stage from StageCache.
     *
     * @param int the stage number to get
     * @return the vector of the info of stage
     */
    static std::vector<std::vector<unsigned int>> getStage(int stage);
};


#endif //MONOREPO_YIJINGLIU1_RESOURCEMANAGER_H
