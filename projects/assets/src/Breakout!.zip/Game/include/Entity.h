//
// Created by Yijing Liu on 2021/2/15.
//

#ifndef MONOREPO_YIJINGLIU1_ENTITY_H
#define MONOREPO_YIJINGLIU1_ENTITY_H

// ==================== Libraries ==================
// Depending on the operating system we use
// The paths to SDL are actually different.
// The #define statement should be passed in
// when compiling using the -D argument.
// This gives an example of how a programmer
// may support multiple platforms with different
// dependencies.
#if defined(LINUX) || defined(MINGW)
#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>
#include <SDL2/SDL_mixer.h>
#include <SDL2/SDL_image.h>
#else
// Windows and Mac use a different path
// If you have compilation errors, change this as needed.
#include <SDL.h>
#include <SDL_ttf.h>
#include <SDL_mixer.h>
#include <SDL_image.h>
#endif

#include "ResourceManager.h"

// ==================== Libraries ==================

/**
 * Entity.h
 *
 * This class provides information about
 * the base class Entity for game objects.
 *
 * @author Yijing Liu
 * @since 2021-02-15
 */
class Entity {
public:
    /**
     * constructor of the Entity class
     *
     * @param renderer the SDL renderer
     */
    Entity(SDL_Renderer* renderer);

    /**
     * virtual destructor of the Entity class
     */
    virtual ~Entity();

    /** the x, y position and width, height of the Entity */
    float x, y, width, height;

    /**
     * Update the position of the entity (virtual).
     *
     * @param delta the time elapsed from last loop in seconds
     */
    virtual void Update(float delta);

    /**
     * Render the entity on the screen (virtual).
     *
     * @param delta the time elapsed from last loop in seconds
     */
    virtual void Render(float delta);

    /**
     * Check if two entities collide.
     *
     * @param other the other entity
     * @return true if collide, false otherwise
     */
    bool Collides(Entity* other);

protected:
    /** the SDL renderer for the entity */
    SDL_Renderer* renderer;
};


#endif //MONOREPO_YIJINGLIU1_ENTITY_H
