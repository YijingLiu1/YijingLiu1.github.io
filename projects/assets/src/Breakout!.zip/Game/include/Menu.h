//
// Created by Yijing Liu on 2021/2/16.
//

#ifndef MONOREPO_YIJINGLIU1_MENU_H
#define MONOREPO_YIJINGLIU1_MENU_H

#include "Text.h"

/** Define the width, height of the screen */
#define SCREEN_WIDTH 1280
#define SCREEN_HEIGHT 720

/**
 * Menu.h
 *
 * This class provides information about
 * the menu in the Breakout! gameplay.
 *
 * @author Yijing Liu
 * @since 2021-02-16
 */
class Menu {
public:
    /**
     * constructor of the Menu class
     *
     * @param font the font for the menu
     * @param langData the vector for game texts in requested language
     */
    Menu(TTF_Font* font, std::vector<std::string> langData);

    /**
     * destructor of the Menu class
     */
    ~Menu();

    /**
     * Update pause texts in the menu.
     *
     * @param renderer the SDL renderer
     */
    void Pause(SDL_Renderer* renderer);

    /**
     * Update win texts in the menu.
     *
     * @param renderer the SDL renderer
     */
    void Win(SDL_Renderer* renderer);

    /**
     * Update lose texts in the menu.
     *
     * @param renderer the SDL renderer
     */
    void Lose(SDL_Renderer* renderer);

    /**
     * Update selection point position in the menu.
     */
    void Select();

    /**
     * Render texts and selection in the menu.
     *
     * @param renderer the SDL renderer
     */
    void Draw(SDL_Renderer* renderer);

    /** the state of the menu */
    int state; // 0: pause; 1: win; 2: lose;
    /** the selection state */
    int choice; // 0/1;
private:
    /**
     * Switch texture of texts in the menu.
     *
     * @param text the text to render
     * @param renderer the SDL renderer
     * @return texture the SDL_Texture pointer of texts
     */
    SDL_Texture* textureSwitch(std::string text, SDL_Renderer* renderer);

    /** the texts for pause menu */
    std::string pauseText[3];
    /** the texts for win menu */
    std::string winText[3];
    /** the texts for lose menu */
    std::string loseText[3];
    /** the textures */
    SDL_Texture* textures[3];
    /** the rectangles for rendering texts */
    SDL_Rect textRect[3];

    /** the rectangle for selection */
    SDL_Rect selection;
    /** the font for menu */
    TTF_Font* font;
    /** the color for menu texts */
    SDL_Color color;
    /** the vector for game texts in requested language */
    std::vector<std::string> langData;
};


#endif //MONOREPO_YIJINGLIU1_MENU_H
