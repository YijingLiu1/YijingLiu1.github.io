//
// Created by Yijing Liu on 2021/2/17.
//

#ifndef MONOREPO_YIJINGLIU1_STAGECACHE_H
#define MONOREPO_YIJINGLIU1_STAGECACHE_H

#include <fstream>
#include <sstream>
#include <map>
#include <string>
#include <iterator>
#include <stdlib.h>
#include <vector>

#if defined(LINUX) || defined(MINGW)
#include <SDL2/SDL.h>
#else
// Windows and Mac use a different path
// If you have compilation errors, change this as needed.
#include <SDL.h>
#endif

// Define the dimensions of the level and bricks
#define BRICK_ROW 12
#define BRICK_COL 12
#define BRICK_WIDTH 64
#define BRICK_HEIGHT 24

/**
 * StageCache.h
 *
 * This class provides information about
 * the StageCache class for game resource,
 * storing cache for stages.
 *
 * @author Yijing Liu
 * @since 2021-02-17
 */
class StageCache {
public:
    /**
     * constructor of the StageCache class
     */
    StageCache();

    /**
     * destructor of the StageCache class
     */
    ~StageCache();

    /**
     * Load the stage into cache.
     *
     * @param resourcePath the resource path for the stage file
     */
    void LoadStage(const char* resourcePath);

    /**
     * Get the stage from cache.
     *
     * @param int the stage number to get
     * @return the vector of the info of stage
     */
    std::vector<std::vector<unsigned int>> GetStage(int stage);

    /**
     * Clear the stage cache.
     */
    void clearStage();

private:
    /** the map storing stages */
    std::map<int, std::vector<std::vector<unsigned int>>> _resourceMap;
    /** empty vector indicating stage not found */
    std::vector<std::vector<unsigned int>> notFound;
};


#endif //MONOREPO_YIJINGLIU1_STAGECACHE_H
