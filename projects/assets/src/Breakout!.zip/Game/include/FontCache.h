//
// Created by Yijing Liu on 2021/2/17.
//

#ifndef MONOREPO_YIJINGLIU1_FONTCACHE_H
#define MONOREPO_YIJINGLIU1_FONTCACHE_H

#include <map>
#include <string>
#include <iterator>


#if defined(LINUX) || defined(MINGW)
#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>
#else
// Windows and Mac use a different path
// If you have compilation errors, change this as needed.
#include <SDL.h>
#include <SDL_ttf.h>
#endif

/**
 * FontCache.h
 *
 * This class provides information about
 * the FontCache class for game resource,
 * storing cache for fonts.
 *
 * @author Yijing Liu
 * @since 2021-02-17
 */
class FontCache {
public:
    /**
     * constructor of the FontCache class
     */
    FontCache();

    /**
     * destructor of the FontCache class
     */
    ~FontCache();

    /**
     * Get the font from cache.
     *
     * @param resourcePath the resource path for the font
     * @param size the font size
     * @return the TTF_Font file pointer of the font and size
     */
    TTF_Font* getFont(const char* resourcePath, int size);

    /**
     * Clear the font cache.
     */
    void clearFont();

private:
    /** the map storing fonts */
    std::map<const char*, TTF_Font*> _resourceMap;
};

#endif //MONOREPO_YIJINGLIU1_FONTCACHE_H
