//
// Created by Yijing Liu on 2021/2/17.
//

#ifndef MONOREPO_YIJINGLIU1_MUSICCACHE_H
#define MONOREPO_YIJINGLIU1_MUSICCACHE_H

#include <map>
#include <string>
#include <iterator>


#if defined(LINUX) || defined(MINGW)
#include <SDL2/SDL.h>
#include <SDL2/SDL_mixer.h>
#else
// Windows and Mac use a different path
// If you have compilation errors, change this as needed.
#include <SDL.h>
#include <SDL_mixer.h>
#endif

/**
 * MusicCache.h
 *
 * This class provides information about
 * the MusicCache class for game resource,
 * storing cache for musics.
 *
 * @author Yijing Liu
 * @since 2021-02-17
 */
class MusicCache {
public:
    /**
     * constructor of the MusicCache class
     */
    MusicCache();

    /**
     * destructor of the MusicCache class
     */
    ~MusicCache();

    /**
     * Get the music from cache.
     *
     * @param resourcePath the resource path for the music
     * @return the Mix_Music file pointer of the music
     */
    Mix_Music* getMusic(const char* resourcePath);

    /**
     * Clear the music cache.
     */
    void clearMusic();

private:
    /** the map storing musics */
    std::map<const char*, Mix_Music*> _resourceMap;
};

#endif //MONOREPO_YIJINGLIU1_MUSICCACHE_H
