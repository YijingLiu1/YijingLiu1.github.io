//
// Created by Yijing Liu on 2021/2/15.
//

#ifndef MONOREPO_YIJINGLIU1_PADDLE_H
#define MONOREPO_YIJINGLIU1_PADDLE_H

#include "Entity.h"

/** Define the speed of the paddle */
#define PADDLE_SPEED 500

/**
 * Paddle.h
 *
 * This class provides information about
 * the paddle in the Breakout! gameplay,
 * derived from the Entity class.
 *
 * @author Yijing Liu
 * @since 2021-02-15
 */
class Paddle: public Entity {
public:
    /**
     * constructor of the Paddle class
     *
     * @param renderer the SDL renderer
     */
    Paddle(SDL_Renderer* renderer);

    /**
     * destructor of the Paddle class
     */
    ~Paddle();

    /**
     * Update the position of the paddle.
     *
     * @param delta the time elapsed from last loop in seconds
     */
    void Update(float delta);

    /**
     * Render the paddle on the screen.
     *
     * @param delta the time elapsed from last loop in seconds
     */
    void Render(float delta);

    /** the speed of the paddle */
    int velocity;

private:
    /** the SDL texture for the paddle */
    SDL_Texture* texture;
};

#endif //MONOREPO_YIJINGLIU1_PADDLE_H
