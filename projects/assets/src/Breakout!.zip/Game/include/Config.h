//
// Created by Yijing Liu on 2021/2/17.
//

#ifndef MONOREPO_YIJINGLIU1_CONFIG_H
#define MONOREPO_YIJINGLIU1_CONFIG_H

#include <fstream>
#include <sstream>
#include <string>
#include <stdlib.h>
#include <vector>
#include <map>
#include <iterator>
#include <string.h>
#include <iostream>

/**
 * Config.h
 *
 * This class provides information about
 * the configuration in the Breakout! gameplay.
 *
 * @author Yijing Liu
 * @since 2021-02-17
 */
class Config {
public:
    /**
     * constructor of the Config class
     */
    Config();

    /**
     * destructor of the Config class
     */
    ~Config();

    /**
     * Load language for the game
     * according to the configuration.
     *
     * @return landData the vector for game texts in requested language
     */
    std::vector<std::string> LoadLanguage();
private:
    /** the map storing config info */
    std::map<std::string, std::string> _configMap;
};


#endif //MONOREPO_YIJINGLIU1_CONFIG_H
