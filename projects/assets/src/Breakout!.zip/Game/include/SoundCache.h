//
// Created by Yijing Liu on 2021/2/17.
//

#ifndef MONOREPO_YIJINGLIU1_SOUNDCACHE_H
#define MONOREPO_YIJINGLIU1_SOUNDCACHE_H

#include <map>
#include <string>
#include <iterator>


#if defined(LINUX) || defined(MINGW)
#include <SDL2/SDL.h>
#include <SDL2/SDL_mixer.h>
#else
// Windows and Mac use a different path
// If you have compilation errors, change this as needed.
#include <SDL.h>
#include <SDL_mixer.h>
#endif

/**
 * SoundCache.h
 *
 * This class provides information about
 * the SoundCache class for game resource,
 * storing cache for sound effects.
 *
 * @author Yijing Liu
 * @since 2021-02-17
 */
class SoundCache {
public:
    /**
     * constructor of the SoundCache class
     */
    SoundCache();

    /**
     * destructor of the SoundCache class
     */
    ~SoundCache();

    /**
     * Get the sound from cache.
     *
     * @param resourcePath the resource path for the sound
     * @return the Mix_Chunk file pointer of the sound
     */
    Mix_Chunk* getSound(const char* resourcePath);

    /**
     * Clear the sound cache.
     */
    void clearSound();

private:
    /** the map storing sounds */
    std::map<const char*, Mix_Chunk*> _resourceMap;
};


#endif //MONOREPO_YIJINGLIU1_SOUNDCACHE_H
